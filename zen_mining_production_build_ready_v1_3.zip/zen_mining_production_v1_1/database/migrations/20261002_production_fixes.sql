-- ZEN MINING production fixes
-- Apply after 20261001_production_hardening.sql. Safe to re-run.

-- Prevent duplicate config rows on repeated setup by ensuring the intended singleton shape.
-- Existing duplicate rows are not deleted automatically; choose the active config before adding this index.

-- Keep reward accrual server-authoritative and strictly bounded to the original 24-hour cycle.
create or replace function public.accrue_device_reward(p_device_id uuid,p_reference text,p_amount numeric)
returns jsonb language plpgsql security definer set search_path=public as $$
declare d public.devices; w public.wallets; existing public.reward_transactions; now_ts timestamptz:=clock_timestamp(); until_ts timestamptz; delta numeric;
begin
 if p_amount<0 then raise exception 'invalid reward'; end if;
 select * into d from public.devices where id=p_device_id for update;
 if d.id is null then raise exception 'device not found'; end if;
 if d.mining_status<>'active' or d.mining_started_at is null or d.mining_ends_at is null then return jsonb_build_object('status','inactive'); end if;
 if now_ts>=d.mining_ends_at then
   update public.devices set mining_status='inactive',last_reward_at=d.mining_ends_at,updated_at=now_ts where id=d.id;
   return jsonb_build_object('status','completed','ends_at',d.mining_ends_at);
 end if;
 if p_amount=0 then return jsonb_build_object('status','no_accrual'); end if;
 select * into existing from public.reward_transactions where reference=p_reference;
 if existing.id is not null then return jsonb_build_object('status','duplicate','transaction_id',existing.id); end if;
 until_ts:=least(now_ts,d.mining_ends_at);
 if d.last_reward_at is null or until_ts<=d.last_reward_at then return jsonb_build_object('status','no_accrual'); end if;
 select * into w from public.wallets where user_id=d.user_id for update;
 if w.id is null then raise exception 'wallet not found'; end if;
 delta:=greatest(0,least(p_amount,d.mining_rate*extract(epoch from (until_ts-d.last_reward_at))/86400.0));
 if delta=0 then return jsonb_build_object('status','no_accrual'); end if;
 insert into public.reward_transactions(wallet_id,device_id,type,amount,reference) values(w.id,d.id,'mining',delta,p_reference);
 update public.wallets set available_balance=available_balance+delta,total_earned=total_earned+delta,updated_at=now_ts where id=w.id;
 update public.devices set last_reward_at=until_ts,mining_status=case when until_ts>=d.mining_ends_at then 'inactive' else 'active' end,updated_at=now_ts where id=d.id;
 return jsonb_build_object('status','accrued','amount',delta,'mining_ends_at',d.mining_ends_at);
end $$;
revoke all on function public.accrue_device_reward(uuid,text,numeric) from public,anon,authenticated;
grant execute on function public.accrue_device_reward(uuid,text,numeric) to service_role;

-- Activity sync fix is implemented in supabase/functions/sync-activity/index.ts.
