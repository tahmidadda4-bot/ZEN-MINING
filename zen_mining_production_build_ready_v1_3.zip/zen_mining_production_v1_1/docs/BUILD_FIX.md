# ZEN MINING Android build repair

The original archive contained only custom Android source files and did not contain a complete Flutter Gradle host project. Modern Flutter also determines Android embedding version from `android/app/src/main/AndroidManifest.xml`; without `<meta-data android:name="flutterEmbedding" android:value="2"/>`, the tool classifies the project as V1.

This version:

- declares Flutter Android V2 embedding explicitly;
- adds INTERNET/AndroidX-compatible Android configuration;
- keeps the native monitoring, boot receiver and method-channel code;
- fixes Dart syntax issues found in profile, wallet, settings, withdrawal, splash and welcome screens;
- adds a deterministic GitHub Actions repair step that generates a clean Android host with Flutter, then restores the ZEN native files;
- builds both APK and AAB with SUPABASE_URL and SUPABASE_ANON_KEY supplied through GitHub Secrets.

The repository was statically audited here. A real Flutter/Android compilation still needs to run in GitHub Actions because the audit environment does not contain the Flutter SDK/Android toolchain.
