import 'package:flutter/material.dart';
import '../widgets/zen_logo.dart';
import '../widgets/green_button.dart';
import 'login.dart';
import 'register.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const SizedBox(height: 20),
              const ZenLogo(size: 60),
              const SizedBox(height: 10),
              const Text('ZEN MINING', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 22),
              Expanded(
                child: ClipRRect(
                  borderRadius: const BorderRadius.all(Radius.circular(24)),
                  child: Image.asset(
                    'assets/images/get_started_hero.png',
                    fit: BoxFit.cover,
                    width: double.infinity,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Turn Your Device Usage Into Real Rewards',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 14),
              const Row(children: [
                Icon(Icons.account_balance_wallet, color: Color(0xFF39E58C), size: 20),
                SizedBox(width: 10),
                Text('Earn by using your device'),
              ]),
              const SizedBox(height: 7),
              const Row(children: [
                Icon(Icons.security, color: Color(0xFF39E58C), size: 20),
                SizedBox(width: 10),
                Text('Safe & secure'),
              ]),
              const Spacer(),
              GreenButton(
                label: 'Get Started',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RegisterScreen()),
                ),
              ),
              const SizedBox(height: 10),
              GreenButton(
                label: 'I Already Have an Account',
                outline: true,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
