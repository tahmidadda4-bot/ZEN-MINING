allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
