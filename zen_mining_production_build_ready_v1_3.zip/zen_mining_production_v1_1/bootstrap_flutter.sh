#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/user_app"

rm -rf /tmp/zen_android_custom /tmp/zen_android_template
mkdir -p /tmp/zen_android_custom/kotlin/com/zenmining/app
cp android/app/src/main/AndroidManifest.xml /tmp/zen_android_custom/AndroidManifest.xml
cp android/app/src/main/kotlin/com/zenmining/app/MainActivity.kt /tmp/zen_android_custom/kotlin/com/zenmining/app/MainActivity.kt
cp android/app/src/main/kotlin/com/zenmining/app/BootReceiver.kt /tmp/zen_android_custom/kotlin/com/zenmining/app/BootReceiver.kt
cp android/app/src/main/kotlin/com/zenmining/app/UsageMonitorService.kt /tmp/zen_android_custom/kotlin/com/zenmining/app/UsageMonitorService.kt

flutter create --platforms=android --org com.zenmining --project-name app /tmp/zen_android_template
rm -rf android
cp -R /tmp/zen_android_template/android android

cp /tmp/zen_android_custom/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
mkdir -p android/app/src/main/kotlin/com/zenmining/app
cp /tmp/zen_android_custom/kotlin/com/zenmining/app/MainActivity.kt android/app/src/main/kotlin/com/zenmining/app/MainActivity.kt
cp /tmp/zen_android_custom/kotlin/com/zenmining/app/BootReceiver.kt android/app/src/main/kotlin/com/zenmining/app/BootReceiver.kt
cp /tmp/zen_android_custom/kotlin/com/zenmining/app/UsageMonitorService.kt android/app/src/main/kotlin/com/zenmining/app/UsageMonitorService.kt
rm -rf android/app/src/main/kotlin/com/zenmining/zen_mining || true

echo "Flutter Android host repaired using the current Flutter template."
