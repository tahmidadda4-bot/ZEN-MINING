# Production Build Audit

This archive was statically audited and repaired for the current Flutter/Android toolchain.

## Android fixes
- Flutter Android V2 embedding is explicitly declared.
- Added missing LaunchTheme/NormalTheme resources.
- Fixed the missing `android.content.Intent` import in `UsageMonitorService.kt`.
- Upgraded Gradle wrapper to 9.3.1.
- Upgraded Android Gradle Plugin to 9.1.1.
- Removed the obsolete `org.jetbrains.kotlin.android` plugin because AGP 9+ provides built-in Kotlin support.
- Java 17 remains the CI target.

## CI checks
The GitHub Actions workflow now:
1. Verifies the Android host and rejects Flutter V1 embedding references.
2. Runs `flutter pub get`.
3. Runs `flutter analyze`.
4. Runs `flutter test`.
5. Runs `flutter clean` and restores dependencies.
6. Builds release APK and AAB with the Supabase URL/public key supplied through GitHub Secrets.
7. Verifies that real APK/AAB files exist before uploading them.
8. Uploads the artifacts only when they are present.

A real Flutter/Android compilation must still run in GitHub Actions because this audit environment does not contain the Flutter SDK.
