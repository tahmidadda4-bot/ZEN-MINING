#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/user_app"
flutter create --org com.zenmining --platforms=android .
echo "Flutter Android project generated. Re-apply the provided android/app/src/main/AndroidManifest.xml and MainActivity.kt if flutter create replaced them, then run flutter pub get."
